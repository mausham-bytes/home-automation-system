#!/usr/bin/env python3
"""
IoT Device Simulator for Home Automation System

This script simulates IoT devices (lights and fans) for testing the home automation system
without requiring physical hardware. It connects to the MQTT broker and responds to commands
just like real ESP32 devices would.

Usage:
    python device_simulator.py

Requirements:
    pip install paho-mqtt
"""

import json
import time
import random
import threading
from datetime import datetime
import paho.mqtt.client as mqtt

class DeviceSimulator:
    def __init__(self, device_type, room, name, mqtt_host='localhost', mqtt_port=1883):
        self.device_type = device_type
        self.room = room
        self.name = name
        self.mqtt_host = mqtt_host
        self.mqtt_port = mqtt_port
        
        # Device state
        self.status = False
        self.brightness = 100 if device_type == 'light' else 0
        self.speed = 0 if device_type == 'fan' else 0
        
        # MQTT topics
        self.command_topic = f"home/{room}/{name}/command"
        self.status_topic = f"home/{room}/{name}/status"
        
        # MQTT client
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        
        self.connected = False
        
    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            self.connected = True
            print(f"[{self.name}] Connected to MQTT broker")
            client.subscribe(self.command_topic)
            print(f"[{self.name}] Subscribed to {self.command_topic}")
            self.publish_status()
        else:
            print(f"[{self.name}] Failed to connect to MQTT broker: {rc}")
    
    def on_message(self, client, userdata, msg):
        try:
            command = json.loads(msg.payload.decode())
            action = command.get('action')
            value = command.get('value')
            
            print(f"[{self.name}] Received command: {action}" + (f" with value: {value}" if value else ""))
            
            if action == 'turn_on':
                self.status = True
                if self.device_type == 'fan' and self.speed == 0:
                    self.speed = 3  # Default to medium speed
            elif action == 'turn_off':
                self.status = False
            elif action == 'set_brightness' and self.device_type == 'light':
                if 0 <= value <= 100:
                    self.brightness = value
            elif action == 'set_speed' and self.device_type == 'fan':
                if 0 <= value <= 5:
                    self.speed = value
                    self.status = value > 0
            
            self.publish_status()
            
        except json.JSONDecodeError:
            print(f"[{self.name}] Failed to decode command JSON")
        except Exception as e:
            print(f"[{self.name}] Error processing command: {e}")
    
    def publish_status(self):
        if not self.connected:
            return
            
        status_data = {
            'status': 'on' if self.status else 'off',
            'device_type': self.device_type,
            'timestamp': time.time()
        }
        
        if self.device_type == 'light':
            status_data['brightness'] = self.brightness
        elif self.device_type == 'fan':
            status_data['speed'] = self.speed
        
        try:
            self.client.publish(self.status_topic, json.dumps(status_data))
            print(f"[{self.name}] Status published: {status_data}")
        except Exception as e:
            print(f"[{self.name}] Failed to publish status: {e}")
    
    def start(self):
        try:
            self.client.connect(self.mqtt_host, self.mqtt_port, 60)
            self.client.loop_start()
            
            # Periodic status updates
            def periodic_status():
                while True:
                    time.sleep(30)  # Publish status every 30 seconds
                    if self.connected:
                        self.publish_status()
            
            status_thread = threading.Thread(target=periodic_status, daemon=True)
            status_thread.start()
            
        except Exception as e:
            print(f"[{self.name}] Failed to start: {e}")
    
    def stop(self):
        self.client.loop_stop()
        self.client.disconnect()

def main():
    print("Starting IoT Device Simulator...")
    print("Make sure the MQTT broker is running on localhost:1883")
    print("Press Ctrl+C to stop\n")
    
    # Create simulated devices
    devices = [
        DeviceSimulator('light', 'living_room', 'main_light'),
        DeviceSimulator('light', 'bedroom', 'bedside_lamp'),
        DeviceSimulator('fan', 'living_room', 'ceiling_fan'),
        DeviceSimulator('fan', 'bedroom', 'desk_fan'),
        DeviceSimulator('light', 'kitchen', 'under_cabinet_lights'),
    ]
    
    # Start all devices
    for device in devices:
        device.start()
        time.sleep(1)  # Small delay between connections
    
    print(f"Started {len(devices)} simulated devices:")
    for device in devices:
        print(f"  - {device.device_type.title()}: {device.room}/{device.name}")
    
    print("\nDevices are now running. Use the web application to control them.")
    print("Press Ctrl+C to stop all devices.\n")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping all devices...")
        for device in devices:
            device.stop()
        print("All devices stopped.")

if __name__ == "__main__":
    main()

