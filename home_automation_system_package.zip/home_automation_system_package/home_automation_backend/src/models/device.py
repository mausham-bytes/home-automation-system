from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Device(db.Model):
    """Model for IoT devices (lights, fans, etc.)"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    device_type = db.Column(db.String(50), nullable=False)  # 'light', 'fan', etc.
    room = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='off')  # 'on', 'off'
    brightness = db.Column(db.Integer, default=100)  # For lights (0-100)
    speed = db.Column(db.Integer, default=0)  # For fans (0-5)
    mqtt_topic = db.Column(db.String(100), nullable=False)  # MQTT topic for this device
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        """Convert device object to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'device_type': self.device_type,
            'room': self.room,
            'status': self.status,
            'brightness': self.brightness,
            'speed': self.speed,
            'mqtt_topic': self.mqtt_topic,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Schedule(db.Model):
    """Model for device scheduling"""
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.Integer, db.ForeignKey('device.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    action = db.Column(db.String(50), nullable=False)  # 'turn_on', 'turn_off', 'set_brightness', etc.
    value = db.Column(db.String(50))  # Value for the action (brightness level, speed, etc.)
    schedule_time = db.Column(db.String(20), nullable=False)  # Time in HH:MM format
    days = db.Column(db.String(20), nullable=False)  # Days of week (e.g., "1,2,3,4,5" for weekdays)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    device = db.relationship('Device', backref=db.backref('schedules', lazy=True))

    def to_dict(self):
        """Convert schedule object to dictionary"""
        return {
            'id': self.id,
            'device_id': self.device_id,
            'device_name': self.device.name if self.device else None,
            'name': self.name,
            'action': self.action,
            'value': self.value,
            'schedule_time': self.schedule_time,
            'days': self.days,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

