from flask import Blueprint, request, jsonify
from src.models.device import db, Device, Schedule
from src.services.mqtt_service import get_mqtt_service
import logging

device_bp = Blueprint('device', __name__)

@device_bp.route('/devices', methods=['GET'])
def get_devices():
    """Get all devices"""
    try:
        devices = Device.query.all()
        return jsonify({
            'success': True,
            'devices': [device.to_dict() for device in devices]
        })
    except Exception as e:
        logging.error(f"Error getting devices: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@device_bp.route('/devices', methods=['POST'])
def create_device():
    """Create a new device"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'device_type', 'room', 'mqtt_topic']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
        
        # Create new device
        device = Device(
            name=data['name'],
            device_type=data['device_type'],
            room=data['room'],
            mqtt_topic=data['mqtt_topic'],
            status=data.get('status', 'off'),
            brightness=data.get('brightness', 100),
            speed=data.get('speed', 0)
        )
        
        db.session.add(device)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'device': device.to_dict()
        }), 201
        
    except Exception as e:
        logging.error(f"Error creating device: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@device_bp.route('/devices/<int:device_id>', methods=['GET'])
def get_device(device_id):
    """Get a specific device"""
    try:
        device = Device.query.get_or_404(device_id)
        return jsonify({
            'success': True,
            'device': device.to_dict()
        })
    except Exception as e:
        logging.error(f"Error getting device {device_id}: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@device_bp.route('/devices/<int:device_id>', methods=['PUT'])
def update_device(device_id):
    """Update a device"""
    try:
        device = Device.query.get_or_404(device_id)
        data = request.get_json()
        
        # Update device fields
        if 'name' in data:
            device.name = data['name']
        if 'device_type' in data:
            device.device_type = data['device_type']
        if 'room' in data:
            device.room = data['room']
        if 'status' in data:
            device.status = data['status']
        if 'brightness' in data:
            device.brightness = data['brightness']
        if 'speed' in data:
            device.speed = data['speed']
        if 'mqtt_topic' in data:
            device.mqtt_topic = data['mqtt_topic']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'device': device.to_dict()
        })
        
    except Exception as e:
        logging.error(f"Error updating device {device_id}: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@device_bp.route('/devices/<int:device_id>', methods=['DELETE'])
def delete_device(device_id):
    """Delete a device"""
    try:
        device = Device.query.get_or_404(device_id)
        db.session.delete(device)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Device deleted successfully'
        })
        
    except Exception as e:
        logging.error(f"Error deleting device {device_id}: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@device_bp.route('/devices/<int:device_id>/control', methods=['POST'])
def control_device(device_id):
    """Send a control command to a device"""
    try:
        device = Device.query.get_or_404(device_id)
        data = request.get_json()
        
        if 'action' not in data:
            return jsonify({'success': False, 'error': 'Missing action parameter'}), 400
        
        action = data['action']
        value = data.get('value')
        
        # Get MQTT service
        mqtt_service = get_mqtt_service()
        
        # Send command via MQTT
        success = mqtt_service.send_device_command(device.room, device.name, action, value)
        
        if success:
            # Update device status in database based on action
            if action == 'turn_on':
                device.status = 'on'
            elif action == 'turn_off':
                device.status = 'off'
            elif action == 'set_brightness' and value is not None:
                device.brightness = int(value)
            elif action == 'set_speed' and value is not None:
                device.speed = int(value)
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': f'Command {action} sent to device {device.name}',
                'device': device.to_dict()
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to send command to device'
            }), 500
            
    except Exception as e:
        logging.error(f"Error controlling device {device_id}: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@device_bp.route('/schedules', methods=['GET'])
def get_schedules():
    """Get all schedules"""
    try:
        schedules = Schedule.query.all()
        return jsonify({
            'success': True,
            'schedules': [schedule.to_dict() for schedule in schedules]
        })
    except Exception as e:
        logging.error(f"Error getting schedules: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@device_bp.route('/schedules', methods=['POST'])
def create_schedule():
    """Create a new schedule"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['device_id', 'name', 'action', 'schedule_time', 'days']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
        
        # Verify device exists
        device = Device.query.get(data['device_id'])
        if not device:
            return jsonify({'success': False, 'error': 'Device not found'}), 404
        
        # Create new schedule
        schedule = Schedule(
            device_id=data['device_id'],
            name=data['name'],
            action=data['action'],
            value=data.get('value'),
            schedule_time=data['schedule_time'],
            days=data['days'],
            is_active=data.get('is_active', True)
        )
        
        db.session.add(schedule)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'schedule': schedule.to_dict()
        }), 201
        
    except Exception as e:
        logging.error(f"Error creating schedule: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@device_bp.route('/schedules/<int:schedule_id>', methods=['DELETE'])
def delete_schedule(schedule_id):
    """Delete a schedule"""
    try:
        schedule = Schedule.query.get_or_404(schedule_id)
        db.session.delete(schedule)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Schedule deleted successfully'
        })
        
    except Exception as e:
        logging.error(f"Error deleting schedule {schedule_id}: {str(e)}")
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

