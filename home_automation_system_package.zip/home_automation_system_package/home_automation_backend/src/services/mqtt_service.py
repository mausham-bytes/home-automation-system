import paho.mqtt.client as mqtt
import json
import logging
from threading import Thread
import time

class MQTTService:
    """MQTT service for communicating with IoT devices"""
    
    def __init__(self, broker_host='localhost', broker_port=1883, username=None, password=None):
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.username = username
        self.password = password
        self.client = mqtt.Client()
        self.is_connected = False
        self.device_status_callbacks = []
        
        # Set up MQTT client callbacks
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        
        # Set up authentication if provided
        if username and password:
            self.client.username_pw_set(username, password)
    
    def _on_connect(self, client, userdata, flags, rc):
        """Callback for when the client receives a CONNACK response from the server"""
        if rc == 0:
            self.is_connected = True
            logging.info(f"Connected to MQTT broker at {self.broker_host}:{self.broker_port}")
            # Subscribe to all device status topics
            client.subscribe("home/+/+/status")  # home/room/device/status
        else:
            self.is_connected = False
            logging.error(f"Failed to connect to MQTT broker. Return code: {rc}")
    
    def _on_disconnect(self, client, userdata, rc):
        """Callback for when the client disconnects from the server"""
        self.is_connected = False
        logging.info("Disconnected from MQTT broker")
    
    def _on_message(self, client, userdata, msg):
        """Callback for when a PUBLISH message is received from the server"""
        try:
            topic = msg.topic
            payload = json.loads(msg.payload.decode())
            logging.info(f"Received message on topic {topic}: {payload}")
            
            # Notify all registered callbacks about device status updates
            for callback in self.device_status_callbacks:
                callback(topic, payload)
                
        except json.JSONDecodeError:
            logging.error(f"Failed to decode JSON message from topic {topic}")
        except Exception as e:
            logging.error(f"Error processing message from topic {topic}: {str(e)}")
    
    def connect(self):
        """Connect to the MQTT broker"""
        try:
            self.client.connect(self.broker_host, self.broker_port, 60)
            # Start the network loop in a separate thread
            self.client.loop_start()
            
            # Wait for connection to be established
            timeout = 10  # seconds
            start_time = time.time()
            while not self.is_connected and (time.time() - start_time) < timeout:
                time.sleep(0.1)
            
            if not self.is_connected:
                raise Exception("Failed to connect to MQTT broker within timeout")
                
        except Exception as e:
            logging.error(f"Error connecting to MQTT broker: {str(e)}")
            raise
    
    def disconnect(self):
        """Disconnect from the MQTT broker"""
        self.client.loop_stop()
        self.client.disconnect()
    
    def publish_command(self, device_topic, command):
        """Publish a command to a device"""
        if not self.is_connected:
            raise Exception("Not connected to MQTT broker")
        
        try:
            command_topic = f"{device_topic}/command"
            payload = json.dumps(command)
            result = self.client.publish(command_topic, payload)
            
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                logging.info(f"Command sent to {command_topic}: {command}")
                return True
            else:
                logging.error(f"Failed to send command to {command_topic}")
                return False
                
        except Exception as e:
            logging.error(f"Error publishing command: {str(e)}")
            return False
    
    def register_status_callback(self, callback):
        """Register a callback function to be called when device status updates are received"""
        self.device_status_callbacks.append(callback)
    
    def send_device_command(self, room, device_name, action, value=None):
        """Send a command to a specific device"""
        command = {
            'action': action,
            'timestamp': time.time()
        }
        
        if value is not None:
            command['value'] = value
        
        device_topic = f"home/{room}/{device_name}"
        return self.publish_command(device_topic, command)

# Global MQTT service instance
mqtt_service = None

def get_mqtt_service():
    """Get the global MQTT service instance"""
    global mqtt_service
    if mqtt_service is None:
        mqtt_service = MQTTService()
    return mqtt_service

def initialize_mqtt_service(broker_host='localhost', broker_port=1883, username=None, password=None):
    """Initialize the global MQTT service"""
    global mqtt_service
    mqtt_service = MQTTService(broker_host, broker_port, username, password)
    try:
        mqtt_service.connect()
        return True
    except Exception as e:
        logging.error(f"Failed to initialize MQTT service: {str(e)}")
        return False

