- [x] Research and Planning
- [x] System Architecture Design
- [x] Backend Development
- [x] Frontend Development
- [x] IoT Integration and Device Control
- [x] Testing and Validation
- [x] Documentation and Repository Setup
- [x] Deployment and Final Delivery

