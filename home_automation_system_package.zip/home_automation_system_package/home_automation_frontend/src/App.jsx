import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Plus, Home, Calendar, Trash2 } from 'lucide-react';
import DeviceCard from './components/DeviceCard';
import DeviceForm from './components/DeviceForm';
import ScheduleForm from './components/ScheduleForm';
import ApiService from './services/api';
import './App.css';

function App() {
  const [devices, setDevices] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deviceFormOpen, setDeviceFormOpen] = useState(false);
  const [scheduleFormOpen, setScheduleFormOpen] = useState(false);
  const [editingDevice, setEditingDevice] = useState(null);
  const [notification, setNotification] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const showNotification = (title, description, type = 'success') => {
    setNotification({ title, description, type });
    setTimeout(() => setNotification(null), 5000);
  };

  const loadData = async () => {
    try {
      setLoading(true);
      const [devicesResponse, schedulesResponse] = await Promise.all([
        ApiService.getDevices(),
        ApiService.getSchedules()
      ]);
      
      setDevices(devicesResponse.devices || []);
      setSchedules(schedulesResponse.schedules || []);
    } catch (error) {
      showNotification("Error", "Failed to load data. Make sure the backend server is running.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleDeviceControl = async (deviceId, action, value = null) => {
    try {
      const response = await ApiService.controlDevice(deviceId, action, value);
      
      if (response.success) {
        // Update device state locally
        setDevices(prev => prev.map(device => 
          device.id === deviceId ? response.device : device
        ));
        
        showNotification("Success", `Device ${action.replace('_', ' ')} command sent successfully.`);
      }
    } catch (error) {
      showNotification("Error", `Failed to control device: ${error.message}`, "error");
    }
  };

  const handleDeviceSave = async (deviceData) => {
    try {
      let response;
      if (editingDevice) {
        response = await ApiService.updateDevice(editingDevice.id, deviceData);
      } else {
        response = await ApiService.createDevice(deviceData);
      }
      
      if (response.success) {
        await loadData(); // Reload data to get updated list
        setDeviceFormOpen(false);
        setEditingDevice(null);
        
        showNotification("Success", `Device ${editingDevice ? 'updated' : 'created'} successfully.`);
      }
    } catch (error) {
      showNotification("Error", `Failed to save device: ${error.message}`, "error");
    }
  };

  const handleScheduleSave = async (scheduleData) => {
    try {
      const response = await ApiService.createSchedule(scheduleData);
      
      if (response.success) {
        await loadData(); // Reload data to get updated list
        setScheduleFormOpen(false);
        
        showNotification("Success", "Schedule created successfully.");
      }
    } catch (error) {
      showNotification("Error", `Failed to create schedule: ${error.message}`, "error");
    }
  };

  const handleDeleteSchedule = async (scheduleId) => {
    try {
      const response = await ApiService.deleteSchedule(scheduleId);
      
      if (response.success) {
        setSchedules(prev => prev.filter(schedule => schedule.id !== scheduleId));
        
        showNotification("Success", "Schedule deleted successfully.");
      }
    } catch (error) {
      showNotification("Error", `Failed to delete schedule: ${error.message}`, "error");
    }
  };

  const openEditDevice = (device) => {
    setEditingDevice(device);
    setDeviceFormOpen(true);
  };

  const openAddDevice = () => {
    setEditingDevice(null);
    setDeviceFormOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your smart home...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {notification && (
        <div className={`fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
          notification.type === 'error' ? 'bg-red-500 text-white' : 'bg-green-500 text-white'
        }`}>
          <h4 className="font-semibold">{notification.title}</h4>
          <p className="text-sm">{notification.description}</p>
        </div>
      )}
      
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Home className="h-8 w-8 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900">Smart Home Automation</h1>
          </div>
          <p className="text-gray-600 text-lg">Control your devices from anywhere</p>
        </header>

        <Tabs defaultValue="devices" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="devices" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              Devices
            </TabsTrigger>
            <TabsTrigger value="schedules" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Schedules
            </TabsTrigger>
          </TabsList>

          <TabsContent value="devices" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold text-gray-900">Your Devices</h2>
              <Button onClick={openAddDevice} className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add Device
              </Button>
            </div>

            {devices.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <Home className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No devices found</h3>
                  <p className="text-gray-600 mb-4">Add your first device to get started with home automation.</p>
                  <Button onClick={openAddDevice}>Add Your First Device</Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {devices.map(device => (
                  <DeviceCard
                    key={device.id}
                    device={device}
                    onControl={handleDeviceControl}
                    onEdit={openEditDevice}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="schedules" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold text-gray-900">Schedules</h2>
              <Button 
                onClick={() => setScheduleFormOpen(true)} 
                className="flex items-center gap-2"
                disabled={devices.length === 0}
              >
                <Plus className="h-4 w-4" />
                Add Schedule
              </Button>
            </div>

            {schedules.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No schedules found</h3>
                  <p className="text-gray-600 mb-4">
                    {devices.length === 0 
                      ? "Add some devices first, then create schedules to automate them."
                      : "Create schedules to automate your devices."
                    }
                  </p>
                  {devices.length > 0 && (
                    <Button onClick={() => setScheduleFormOpen(true)}>Create Your First Schedule</Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {schedules.map(schedule => (
                  <Card key={schedule.id} className="hover:shadow-lg transition-shadow duration-200">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-lg font-semibold">{schedule.name}</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteSchedule(schedule.id)}
                        className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <p className="text-sm font-medium">Device: {schedule.device_name}</p>
                        <p className="text-sm text-muted-foreground">Action: {schedule.action.replace('_', ' ')}</p>
                        {schedule.value && (
                          <p className="text-sm text-muted-foreground">Value: {schedule.value}</p>
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium">Time: {schedule.schedule_time}</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {schedule.days.split(',').map(day => {
                            const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                            return (
                              <Badge key={day} variant="secondary" className="text-xs">
                                {dayNames[parseInt(day)]}
                              </Badge>
                            );
                          })}
                        </div>
                      </div>
                      <Badge variant={schedule.is_active ? "default" : "secondary"}>
                        {schedule.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <DeviceForm
          device={editingDevice}
          isOpen={deviceFormOpen}
          onClose={() => {
            setDeviceFormOpen(false);
            setEditingDevice(null);
          }}
          onSave={handleDeviceSave}
        />

        <ScheduleForm
          devices={devices}
          isOpen={scheduleFormOpen}
          onClose={() => setScheduleFormOpen(false)}
          onSave={handleScheduleSave}
        />
      </div>
    </div>
  );
}

export default App;
