import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

const ScheduleForm = ({ devices, isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    device_id: '',
    name: '',
    action: '',
    value: '',
    schedule_time: '',
    days: []
  });

  const daysOfWeek = [
    { id: '1', label: 'Monday' },
    { id: '2', label: 'Tuesday' },
    { id: '3', label: 'Wednesday' },
    { id: '4', label: 'Thursday' },
    { id: '5', label: 'Friday' },
    { id: '6', label: 'Saturday' },
    { id: '0', label: 'Sunday' }
  ];

  const actions = [
    { value: 'turn_on', label: 'Turn On' },
    { value: 'turn_off', label: 'Turn Off' },
    { value: 'set_brightness', label: 'Set Brightness' },
    { value: 'set_speed', label: 'Set Speed' }
  ];

  useEffect(() => {
    if (!isOpen) {
      setFormData({
        device_id: '',
        name: '',
        action: '',
        value: '',
        schedule_time: '',
        days: []
      });
    }
  }, [isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const scheduleData = {
      ...formData,
      days: formData.days.join(',')
    };
    
    onSave(scheduleData);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleDayToggle = (dayId) => {
    setFormData(prev => ({
      ...prev,
      days: prev.days.includes(dayId)
        ? prev.days.filter(d => d !== dayId)
        : [...prev.days, dayId]
    }));
  };

  const selectedDevice = devices.find(d => d.id.toString() === formData.device_id);
  const showValueField = formData.action === 'set_brightness' || formData.action === 'set_speed';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create Schedule</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Schedule Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="e.g., Morning Lights"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="device_id">Device</Label>
            <Select
              value={formData.device_id}
              onValueChange={(value) => handleInputChange('device_id', value)}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select device" />
              </SelectTrigger>
              <SelectContent>
                {devices.map(device => (
                  <SelectItem key={device.id} value={device.id.toString()}>
                    {device.name} ({device.room})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="action">Action</Label>
            <Select
              value={formData.action}
              onValueChange={(value) => handleInputChange('action', value)}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent>
                {actions.map(action => {
                  // Filter actions based on device type
                  if (selectedDevice) {
                    if (action.value === 'set_brightness' && selectedDevice.device_type !== 'light') {
                      return null;
                    }
                    if (action.value === 'set_speed' && selectedDevice.device_type !== 'fan') {
                      return null;
                    }
                  }
                  return (
                    <SelectItem key={action.value} value={action.value}>
                      {action.label}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {showValueField && (
            <div className="space-y-2">
              <Label htmlFor="value">
                {formData.action === 'set_brightness' ? 'Brightness (0-100)' : 'Speed (0-5)'}
              </Label>
              <Input
                id="value"
                type="number"
                value={formData.value}
                onChange={(e) => handleInputChange('value', e.target.value)}
                min={0}
                max={formData.action === 'set_brightness' ? 100 : 5}
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="schedule_time">Time</Label>
            <Input
              id="schedule_time"
              type="time"
              value={formData.schedule_time}
              onChange={(e) => handleInputChange('schedule_time', e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Days of Week</Label>
            <div className="grid grid-cols-2 gap-2">
              {daysOfWeek.map(day => (
                <div key={day.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={day.id}
                    checked={formData.days.includes(day.id)}
                    onCheckedChange={() => handleDayToggle(day.id)}
                  />
                  <Label htmlFor={day.id} className="text-sm">
                    {day.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              Create Schedule
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ScheduleForm;

