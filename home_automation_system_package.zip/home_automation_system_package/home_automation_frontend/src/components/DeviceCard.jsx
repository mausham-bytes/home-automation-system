import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Lightbulb, Fan, Power, Settings } from 'lucide-react';

const DeviceCard = ({ device, onControl, onEdit }) => {
  const getDeviceIcon = (type) => {
    switch (type) {
      case 'light':
        return <Lightbulb className="h-6 w-6" />;
      case 'fan':
        return <Fan className="h-6 w-6" />;
      default:
        return <Power className="h-6 w-6" />;
    }
  };

  const handleToggle = () => {
    const action = device.status === 'on' ? 'turn_off' : 'turn_on';
    onControl(device.id, action);
  };

  const handleBrightnessChange = (value) => {
    onControl(device.id, 'set_brightness', value[0]);
  };

  const handleSpeedChange = (value) => {
    onControl(device.id, 'set_speed', value[0]);
  };

  return (
    <Card className="w-full max-w-sm hover:shadow-lg transition-shadow duration-200">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          {getDeviceIcon(device.device_type)}
          {device.name}
        </CardTitle>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onEdit(device)}
          className="h-8 w-8 p-0"
        >
          <Settings className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Status</span>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              {device.status === 'on' ? 'On' : 'Off'}
            </span>
            <Switch
              checked={device.status === 'on'}
              onCheckedChange={handleToggle}
            />
          </div>
        </div>

        {device.device_type === 'light' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Brightness</span>
              <span className="text-sm text-muted-foreground">{device.brightness}%</span>
            </div>
            <Slider
              value={[device.brightness]}
              onValueChange={handleBrightnessChange}
              max={100}
              step={1}
              className="w-full"
              disabled={device.status === 'off'}
            />
          </div>
        )}

        {device.device_type === 'fan' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Speed</span>
              <span className="text-sm text-muted-foreground">Level {device.speed}</span>
            </div>
            <Slider
              value={[device.speed]}
              onValueChange={handleSpeedChange}
              max={5}
              step={1}
              className="w-full"
              disabled={device.status === 'off'}
            />
          </div>
        )}

        <div className="text-xs text-muted-foreground">
          Room: {device.room}
        </div>
      </CardContent>
    </Card>
  );
};

export default DeviceCard;

