import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const DeviceForm = ({ device, isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: '',
    device_type: '',
    room: '',
    mqtt_topic: ''
  });

  useEffect(() => {
    if (device) {
      setFormData({
        name: device.name || '',
        device_type: device.device_type || '',
        room: device.room || '',
        mqtt_topic: device.mqtt_topic || ''
      });
    } else {
      setFormData({
        name: '',
        device_type: '',
        room: '',
        mqtt_topic: ''
      });
    }
  }, [device, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Generate MQTT topic if not provided
    const mqttTopic = formData.mqtt_topic || `home/${formData.room}/${formData.name.toLowerCase().replace(/\s+/g, '_')}`;
    
    onSave({
      ...formData,
      mqtt_topic: mqttTopic
    });
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {device ? 'Edit Device' : 'Add New Device'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Device Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="e.g., Living Room Light"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="device_type">Device Type</Label>
            <Select
              value={formData.device_type}
              onValueChange={(value) => handleInputChange('device_type', value)}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select device type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="light">Light</SelectItem>
                <SelectItem value="fan">Fan</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="room">Room</Label>
            <Input
              id="room"
              value={formData.room}
              onChange={(e) => handleInputChange('room', e.target.value)}
              placeholder="e.g., living_room"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="mqtt_topic">MQTT Topic (Optional)</Label>
            <Input
              id="mqtt_topic"
              value={formData.mqtt_topic}
              onChange={(e) => handleInputChange('mqtt_topic', e.target.value)}
              placeholder="Auto-generated if empty"
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              {device ? 'Update' : 'Add'} Device
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default DeviceForm;

